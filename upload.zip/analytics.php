
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN"
"http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html>
	<head>
		<title>Teer | BHUTAN |  Teer Results Online | Target: teerbhutan.com</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
		<meta name="keyword" content="teer,BHUTAN,teer result,lottery result,analytics">	
		<link href="css/style1.css" media="all" rel="stylesheet" type="text/css" />
		<link rel="shortcut icon" href="images/16.ico" type="image/x-icon" />
		<script>
		  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
		  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
		  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

		  ga('create', 'UA-54245329-2', 'auto');
		  ga('send', 'pageview');

		</script>	
		<!-- Start Alexa Certify Javascript -->
		<script type="text/javascript">
		_atrk_opts = { atrk_acct:"hYtMk1a4eFf2cv", domain:"teerbhutan.com",dynamic: true};
		(function() { var as = document.createElement('script'); as.type = 'text/javascript/index.htm'; as.async = true; as.src = "https://d31qbv1cthcecs.cloudfront.net/atrk.js"; var s = document.getElementsByTagName('script')[0];s.parentNode.insertBefore(as, s); })();
		</script>
		<noscript><img src="../d5nxst8fruw4z.cloudfront.net/atrk.gif-account=hYtMk1a4eFf2cv" style="display:none" height="1" width="1" alt="" /></noscript>
		<!-- End Alexa Certify Javascript -->  	
	</head>
	<body>
		<!----- start-header---->
			<div id="home" class="header">
					<div class="top-header">
					<a href="index.php"><img src="images/teer.jpg" title ="Teer" Alt= "Teer"></a>
				</div>
			</div>
			<div id="work" class="work" style="background-color:white;">
							<!--Adsense Responsive Unit Start-->
								<script async src="../pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
								<!-- Responsive -->
								<ins class="adsbygoogle"
								     style="display:block"
								     data-ad-client="ca-pub-5824382477682918"
								     data-ad-slot="9616795697"
								     data-ad-format="auto"></ins>
								<script>
								(adsbygoogle = window.adsbygoogle || []).push({});
								</script>	
							<!--Adsense Responsive Unit End -->													
							<div class="container" style="background-color:white;">
							<div class="head-one text-center team-head">
								<p></p>
								<!--<table class="table2">-->
								<div style ="margin-bottom:1.5em;margin-top:1.5em;">
								<a href='Ashif.html'><button style='background-color :#EBEDED;color:black;padding:0.5em;font-size:1.0em;width:60%;'>Target by Md Ashif Prince : Teer Champion</button></a>
								</div>
								<div style ="margin-bottom:1.5em;margin-top:1.5em;">
								<a href='champ-permit.php.htm'><button style='background-color :#EBEDED;color:black;padding:0.5em;font-size:1.0em;width:60%;'>View Predictions By Teer Champions</button></a>
								</div>
								<div style ="margin-bottom:1.5em;">
								<a href='mypredictions-analytics.php.htm'><button style='background-color :#EBEDED;color:black;padding:0.5em;font-size:1.0em;width:60%;'>My Prediction Analysis</button></a>
								</div>
								<div style ="margin-bottom:1.5em;">
								<a href='player-permit.php.htm'><button style='background-color :#EBEDED;color:black;padding:0.5em;font-size:1.0em;width:60%;'>View Predictions of a Player</button></a>
								</div>
								<!--</table>-->
							</div>
							<!--Adsense Responsive Unit Start-->
								<script async src="../pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
								<!-- Responsive -->
								<ins class="adsbygoogle"
								     style="display:block"
								     data-ad-client="ca-pub-5824382477682918"
								     data-ad-slot="9616795697"
								     data-ad-format="auto"></ins>
								<script>
								(adsbygoogle = window.adsbygoogle || []).push({});
								</script>	
							<!--Adsense Responsive Unit End -->
							
					<div id="work1" class="container" style="background-color:white;">
					<!---works--->
					<div class="works">
							<div id="whatever">
									<div class="col-md-50 work-grid">
								    <div class="item1">
								         <a href="index.php"><img src="images/teer-result.jpg" title="Home"  alt="Online Teer Result"/></a>								        
								    </div>  
							    </div> 
								<div class="col-md-50 work-grid">
								    <div class="item1">
								        <a href="#"><img src="images/teercounterSocial.jpg" title="teercounterSocial" alt="TeerCounter Social Network" /></a>
								        
								    </div>  
							    </div> 
								<div class="col-md-50 work-grid">
								    <div class="item1">
								        <a href="dream-numbers.php"><img src="images/teer-dream-numbers.jpg" title="Dream Number" alt="Teer Dream Numbers" /></a>							        
								    </div>  
							    </div> 
								<div class="col-md-50 work-grid">
								    <div class="item1">
								        <a href="win-prizes.php.htm"><img src="images/teer-win-prizes.jpg" title="Win Prizes"  alt="TeerCounter Win Prizes" /></a>								        
								    </div>  
							    </div> 
								<div class="col-md-50 work-grid">
								    <div class="item1">
								        <a href="lotteries.html"><img src="images/teer-forum.jpg" title="Groups" alt="TeerCounter Forum"/></a>						        
								    </div>  
							    </div> 
								<div class="col-md-50 work-grid">
								    <div class="item1">
								        <a href="common-numbers.php"><img src="images/teer-common-numbers.jpg" title="Common Number" Alt=" Teer Common Numbers" /></a>								        
								    </div>  
							    </div> 	
						</div>
			</div>
			<!--anuja inserted footer-->
<div class='footer-left1'><a href='termsofuse.php'><u>Terms</u></a></div><div class='footer-center1'><a href='contact-us.php'><u>Contact Us</u></a></div><div class='footer-right1'><a href='privacypolicy.php'><u>Privacy Policy</u></a></div><!--footer ends here-->	</body>
</html>