<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN"
"http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html>
	<head>
		<title>Teer | BHUTAN | Teer Results Online | Contact Us: teerbhutan.com </title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
		<meta name="title" content="Contact teerbhutan.com ">
		<meta name="description" content="If you have any queries, complaints or suggestions, feel free to get in touch.">
		<meta name="keyword" content="teer,BHUTAN,teer result,lottery result,contact teercounter">
		<link href="css/style1.css" media="all" rel="stylesheet" type="text/css" />
		<link rel="shortcut icon" href="images/16.ico" type="image/x-icon" />
		<script>
		  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
		  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
		  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

		  ga('create', 'UA-54245329-2', 'auto');
		  ga('send', 'pageview');

		</script>
		<!-- Start Alexa Certify Javascript -->
		<script type="text/javascript">
		_atrk_opts = { atrk_acct:"hYtMk1a4eFf2cv", domain:"teerbhutan.com",dynamic: true};
		(function() { var as = document.createElement('script'); as.type = 'text/javascript/index.htm'; as.async = true; as.src = "https://d31qbv1cthcecs.cloudfront.net/atrk.js"; var s = document.getElementsByTagName('script')[0];s.parentNode.insertBefore(as, s); })();
		</script>
		<noscript><img src="../d5nxst8fruw4z.cloudfront.net/atrk.gif-account=hYtMk1a4eFf2cv" style="display:none" height="1" width="1" alt="" /></noscript>
		<!-- End Alexa Certify Javascript -->  		
		
		<script>
		function validateForm() {
	var x = document.forms["panel"]["prob"].value;
    if (x == null || x == "") {
        alert("Please Write Your Message To Us");
        return false;
    }
	var x = document.forms["panel"]["from"].value;
    if (x == null || x == "") {
        alert("Please Enter Your Email Address");
        return false;
    }
	var x = document.forms["panel"]["from"].value;
    var atpos = x.indexOf("@");
    var dotpos = x.lastIndexOf(".");
    if (atpos< 1 || dotpos<atpos+2 || dotpos+2>=x.length) {
        alert("Not a valid e-mail address");
        return false;
    }
	}
		</script>
	</head>
	<body>
		<!----- start-header---->
			<div id="home" class="header">
					<div class="top-header">
					<a href="index.php"><img src="images/teer.jpg" title ="Teer" Alt= "Teer"></a>
				</div>
			</div>
			<div id="work" class="work" style="background-color:white;">													
							<div class="container" style="background-color:white;">
							<div id="contact" class="contact" style="background-color:white;">
							<div class="container" style="background-color:white;">
							<div class="head-one text-center">
								<h2>contact Us</h2>
								<span> </span>
								<h3>Have questions about Results, Common Numbers, Contests or Mobile Apps?</h3>
								<h3><a href="Social/groups/contact-teercounter-com/index.htm"><u>Click Here to Chat with Us</u></a></h3>
								<span> </span>
							</div>
							<div align="center" class="contact-grids">
								<div class="col-md-7 contact-form">
								<p>For everything else, just drop us a line below.</p>	
								<form  id ="panel" action="contact-submit.php" method="POST" onsubmit="return validateForm()">
									<textarea name="prob"  id="prob" placeholder="Leave us a message..." required> </textarea></br>
										<p>Your Email:</p>
									<input type="text" value="" name="from" placeholder="Your@mail.com" required>
									<input type="submit" name="submit" value="Send" />									
								</form>
								</br>
								</div>
								<div class="clear"> </div>
							</div>
						</div>
					</div>									
					<div id="work1" class="container" style="background-color:white;">
					<!---works--->
					<div class="works">
							<div id="whatever">
								<div class="col-md-50 work-grid">
								    <div class="item1">
								        <a href="index.php"><img src="images/teer-result.jpg" title="Home"  alt="Online Teer Result"/></a>								        
								    </div>  
							    </div> 
								<div class="col-md-50 work-grid">
								    <div class="item1">
								        <a href="Social/index.htm"><img src="images/teercounterSocial.jpg" title="teercounterSocial" alt="TeerCounter Social Network" /></a>						        
								    </div>  
							    </div> 
								
								<div class="col-md-50 work-grid">
								    <div class="item1">
								        <a href="common-numbers.php"><img src="images/teer-common-numbers.jpg" title="Common Number" Alt=" Teer Common Numbers" /></a>								        
								    </div>  
							    </div> 
								
								<div class="col-md-50 work-grid">
								    <div class="item1">
								        <a href="lotteries.html"><img src="images/Home.jpg" title="Teer and Lottery Home" alt="Teer and Lottery Home"/></a>								        
								    </div>  
							    </div> 
								
								<div class="col-md-50 work-grid">
								    <div class="item1">
								        <a href="dream-numbers.php"><img src="images/teer-dream-numbers.jpg" title="Dream Number" alt="Teer Dream Numbers" /></a>								        
								    </div>  
							    </div> 
								
								
								<div class="col-md-50 work-grid">
								    <div class="item1">
								        <a href="previous-result.php"><img src="images/teer-previous-numbers.jpg" title="Previous Result" alt="Teer Previous Results"  /></a>								        
								    </div>  
							    </div> 	
						</div>
			</div>
			<!--anuja inserted footer-->
<div class='footer-left1'><a href='termsofuse.php'><u>Terms</u></a></div><div class='footer-center1'><a href='contact-us.php'><u>Contact Us</u></a></div><div class='footer-right1'><a href='privacypolicy.php'><u>Privacy Policy</u></a></div><!--footer ends here-->	</body>
</html>