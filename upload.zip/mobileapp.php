<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN"
"http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html>
	<head>
		<title>Teer | BHUTAN | Teer Results Online | Contact Us: teerbhutan.com </title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
		<meta name="title" content="Contact teerbhutan.com ">
		<meta name="description" content="If you have any queries, complaints or suggestions, feel free to get in touch.">
		<meta name="keyword" content="teer,BHUTAN,teer result,lottery result,contact teercounter">
		<link href="css/style1.css" media="all" rel="stylesheet" type="text/css" />
		<link rel="shortcut icon" href="images/16.ico" type="image/x-icon" />
	</head>
	<body>
		<!----- start-header---->
			<div id="home" class="header">
					<div class="top-header">
					<a href="index.php"><img src="images/teer.jpg" title ="Teer" Alt= "Teer"></a>
				</div>
			</div>
			<!---work--->
			<!--
			<div id="work" class="work" style="background-color:white;">			
			<div class="container" style="background-color:white;">	
			<div class="head-one text-center team-head">
			<div style="margin-left:2em; float:left;"><img src="images/Arrow.jpg"></div>											
			<div style="margin-right:2em;float:right;"><img src="images/Home.jpg"></div>	
			</div>
			</div>
			</div>
			-->
			<div id="work" class="work" style="background-color:white;">													
							<div class="container" style="background-color:white;">
							<div id="contact" class="contact" style="background-color:white;">
							<div class="container" style="background-color:white;">
							<div class="head-one text-center">
								<h2></h2>
								<span> </span>
							</div>
							<div align="center" class="contact-grids">
								<div class="col-md-7 contact-form">
								<h1>Download Android App</h1>
								</br>
								<form action="#" method="POST">
								<!--<a href="TeerCounter.apk"><img src="images/downloadnew.jpg" id="submit" name="submit" /></a>-->
								<input type="image" src="images/downloadnew.jpg" id="submit" name="submit" />
								</form>
								</div>							
								
								<div class="clear"> </div>
							</div>
						</div>
					</div>									
					<div id="work1" class="container" style="background-color:white;">
					<!---works--->
					<div class="works">
							<div id="whatever">
								<div class="col-md-50 work-grid">
								    <div class="item1">
								        <a href="index.php"><img src="images/teer-result.jpg" title="Home" alt="Online Teer Result"/></a>									        
								    </div>  
							    </div> 
								
								<div class="col-md-50 work-grid">
								    <div class="item1">
								        <a href="Social/index.htm"><img src="images/teercounterSocial.jpg" title="teercounterSocial" alt="TeerCounter Social Network" /></a>						        
								    </div>  
							    </div> 
								
								
								
								<div class="col-md-50 work-grid">
								    <div class="item1">
								        <a href="lotteries.html"><img src="images/teer-forum.jpg" title="Groups" alt="TeerCounter Forum" /></a>								        
								    </div>  
							    </div> 
								<div class="col-md-50 work-grid">
								    <div class="item1">
								        <a href="win-prizes.php.htm"><img src="images/teer-win-prizes.jpg" title="Win Prizes"  alt="TeerCounter Win Prizes" /></a>								        
								    </div>  
							    </div> 
								
								<div class="col-md-50 work-grid">
								    <div class="item1">
								        <a href="common-numbers.php"><img src="images/teer-common-numbers.jpg" title="Common Number" Alt=" Teer Common Numbers" /></a>								        							        
								    </div>  
							    </div> 
								
								<div class="col-md-50 work-grid">
								    <div class="item1">
								        <a href="previous-result.php"><img src="images/teer-previous-numbers.jpg" title="Previous Result" alt="Teer Previous Results"  /></a>								        
								    </div>  
							    </div> 	
						</div>
			</div>
			<!--anuja inserted footer-->
<div class='footer-left1'><a href='termsofuse.php'><u>Terms</u></a></div><div class='footer-center1'><a href='contact-us.php'><u>Contact Us</u></a></div><div class='footer-right1'><a href='privacypolicy.php'><u>Privacy Policy</u></a></div><!--footer ends here-->	</body>
</html>