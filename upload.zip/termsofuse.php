<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN"
"http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html>
	<head>
		<title>Teer | BHUTAN | Teer Results Online | Contact Us: teerbhutan.com </title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
		<meta name="title" content="Contact teerbhutan.com ">
		<meta name="description" content="If you have any queries, complaints or suggestions, feel free to get in touch.">
		<meta name="keyword" content="teer,BHUTAN,teer result,lottery result,contact teercounter">
		<link href="css/style1.css" media="all" rel="stylesheet" type="text/css" />
		<link rel="shortcut icon" href="images/16.ico" type="image/x-icon" />
		
		<script>
		  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
		  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
		  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

		  ga('create', 'UA-54245329-2', 'auto');
		  ga('send', 'pageview');

		</script>	
		<script>
  window.fbAsyncInit = function() {
    FB.init({
      appId      : '319452894894262',
      xfbml      : true,
      version    : 'v2.1'
    });
  };

  (function(d, s, id){
     var js, fjs = d.getElementsByTagName(s)[0];
     if (d.getElementById(id)) {return;}
     js = d.createElement(s); js.id = id;
     js.src = "//connect.facebook.net/en_US/sdk.js";
     fjs.parentNode.insertBefore(js, fjs);
   }(document, 'script', 'facebook-jssdk'));
</script>

<!-- Start Alexa Certify Javascript -->
		<script type="text/javascript">
		_atrk_opts = { atrk_acct:"hYtMk1a4eFf2cv", domain:"teerbhutan.com",dynamic: true};
		(function() { var as = document.createElement('script'); as.type = 'text/javascript/index.htm'; as.async = true; as.src = "https://d31qbv1cthcecs.cloudfront.net/atrk.js"; 				var s = document.getElementsByTagName('script')[0];s.parentNode.insertBefore(as, s); })();
		</script>
		<noscript><img src="../d5nxst8fruw4z.cloudfront.net/atrk.gif-account=hYtMk1a4eFf2cv" style="display:none" height="1" width="1" alt="" /></noscript>
		<!-- End Alexa Certify Javascript -->  	
	</head>
	<body>
		<!----- start-header---->
			<div id="home" class="header">
					<div class="top-header">
					<a href="index.php"><img src="images/teer.jpg" title="Teer" Alt="Teer"></a>
				</div>
			</div>			
				</div>
			</div>
			<!--//banner---->
			<div class="banner text-center">
				
				<div  align="centre">
					</br></br>
					
	<div align="left">
	<p><strong>Terms of Use</strong></p>
<p>&nbsp;</p>
<p>Your use of the products and/or services (hereinafter referred to as "Services") currently offered or to be offered in future by Teer Counter, its subsidiaries, affiliates, licensors, associates and partners (hereinafter referred as "Teer Counter") through the website www.teerbhutan.com (hereinafter referred as "Website") is subject to and governed by these Terms of Service, Privacy Policy including the sub-sections of these sections on the Website (hereinafter referred as "Terms").</p>
<p><strong>You understand that teerbhutan.com website is acting in capacity of intermediary as defined under Information Technology Act 2000 and abides by all rules</strong><strong> applicable to intermediaries.</strong><strong>teerbhutan.com currently displays results for BHUTAN Teer which is archery based state run gambling activity legalized in that state. It may add similar events in future. In the event of a result reported by website is incorrect, the website couldn&rsquo;t be held responsible. The users are advised to verify the results from an authorized counter. Teer Results are advised to be viewed by people residing in parts of Meghalaya only. Website is in no way associated with the conduction of this event nor claims to be having connection with said event in any manner. The website only facilitates the updating of information about said events through online means.</strong></p>
<p>You understand that the Terms will be binding on you. You agree that Services offered on the Website can be accessed only in accordance with the Terms and you shall be responsible to comply with the Terms at all times. You are responsible to be aware of and agree to abide by the Terms as published and periodically amended or modified by Teer Counter.</p>
<p><strong>The website may promote events like lucky number / common number for the day, dream number for the day or any other similar gaming events and these events does not relate or guarantee any monitory rewards and are sheer gaming events played for relaxation and pleasure and enhancing skills. teerbhutan.com has a &ldquo;Predict Target&rdquo; feature where registered user&rsquo;s can participate and predict the Teer Result for the day. In case the prediction is correct then the registered user will be awarded points. On the basis of these points, the rank of a user will be decided. There is no prize, monetory or otherwise for this competition and this is purely a play-for-fun game. </strong></p>
<p><strong>You specifically understand that Lucky number / Common number are just guiders based on some machine generated data compilation programs and to rely on same is the sole discretion of the user. Website does not own any responsibility about such Lucky or common numbers. Similarly the &ldquo;Predict Target&rdquo; is a fun game for ranks and not for any monitory gains.</strong></p>
<p><strong>You specifically understand that &ldquo;Dream number&rdquo; is based on legends and mythology. Many people have a belief that their dreams have some guiding meaning. Website has just compiled the meanings for benefit of users and doesn&rsquo;t claim correctness of the same.</strong></p>
<p>If any of the Terms /<strong>Services</strong> is determined to be unlawful, invalid, void or unenforceable for any reason by any judicial or quasi - judicial body in India, it will not affect the validity and enforceability of the remaining Terms.</p>
<p>Our failure or delay to act or exercise any right or remedy with respect to a breach of any of the Terms by you shall not be construed as a waiver of our right to act with respect to the said breach or any prior, concurrent, subsequent or similar breaches.</p>
<p>If a promotion, game, event, competition or tournament is organized by us on the Website, it shall be governed by the Terms and any supplementary terms and conditions which may be specifically applicable for that promotion, game, event, competition or tournament.</p></br>
<p><strong>1. Legality</strong></p>
<p>You may only use the Services offered through this website if you are 18 years of age or over. Access to our Services or any part thereof may be restricted by us from time to time in our sole decision. You confirm that you are accessing the Services with understanding all the terms and conditions and legalities involved.</p></br>
<p><strong>2. Game Services</strong></p>
<p>All promotions/ activities/ skilled guessing and/or similar competitions organized on the Website are collectively referred as "Skilled Activities&rdquo; as defined by appropriate law for time being in force. All activities/competitions offered on the Website are defined as Non-Cash Activity (ies).</p></br>
<p><strong>3. User representations</strong></p>
<p>Any information provided by you to us, whether at the stage of registration or during anytime subsequently, should be complete and truthful.</p>
<p>You represent that you are 18 years of age or older and competent to enter into transactions with other users. With full knowledge of the facts and circumstances surrounding this Activity, you are voluntarily participating in the Activity and assume all responsibility for and risk resulting from your participation, including all risk of financial loss. You agree to indemnify and hold Teer Counter, its employees, directors, officers, and agents harmless with respect to any and all claims and costs associated with your participation in the Activity.</p>
<p>You represent that you have the experience and the requisite skills required to participate in the Activity and that you are not aware of any physical or mental condition that would impair your capability to fully participate in the Activity. You further acknowledge that you are solely responsible for any consequence resulting from your participating in this Activity or being associated with this Activity or around this Activity. You understand that Teer Counter assumes no liability or responsibility for any loss, financial or otherwise, that you may sustain as a result of participation in the Activity.</p>
<p>You understand and agree that you are solely responsible for all content posted, transmitted, uploaded or otherwise made available on the Website by you. All content posted by you must be legally owned by or licensed to you. By publishing any content on the Website, you agree to grant us a royalty-free, world-wide, non-exclusive, perpetual and assignable right to use, copy, reproduce, modify, adapt, publish, edit, translate, create derivative works from, transmit, distribute, publicly display, and publicly perform your content and to use such content in any related marketing materials produced by us or our affiliates. Such content may include, without limitation, your name, username, location, messages, gender or pictures. You also understand that you do not obtain any rights, legal or equitable, in any material incorporating your content. You further agree and acknowledge that Teer Counter has the right to use in any manner whatsoever, all communication or feedback provided by you.</p>
<p>You understand and accept that Teer Counter reserves the right to record any and all user content produced by way of but not limited to chat messages on the Website through the Teer Counter feature or other interactive features, if any, offered as part of the Services.</p>
<p>You shall not hold Teer counter responsible for not being able to participate in any Activity for which you may be eligible to participate. This includes, but is not limited to situations where you are unable to log into your user account as your user account may be pending validation or you may be in suspected or established violation of any of the Terms.</p>
<p>You understand and accept that by viewing or using the Website or availing of any Services, or using communication features on the Website, you may be exposed to content posted by other users which you may find offensive, objectionable or indecent. You may bring such content posted by other users to our notice that you may find offensive, objectionable or indecent and we reserve the right to act upon it as we may deem fit. The decision taken by us on this regard shall be final and binding on you.</p></br>
<p><strong>4. User Account Creation &amp; Operation</strong></p>
<p>To use our Services, you will need to register with us on the Website.</p>
<p>By completing the online registration process on the Website, you confirm you acceptance of the Terms.</p>
<p>During the registration process, you will be required to choose a login name and a password in addition to providing some other information which may not be mandatory. Additionally, you may be required to give further personal information for your user account verification and/or for adding extra features to your user account. You must give us the correct details in all fields requiring your personal information, including, without limitation, your name, postal address, email address, telephone number(s) etc. You undertake that you will update this information and keep it current.</p>
<p>You acknowledge that we may, at any time, require you to verify the correctness of this information and in order to do so may require additional documentary proof from you, failing which we reserve the right to suspend or terminate your registration on the Website.</p>
<p>Any information provided by you to us should be complete and truthful to the best of your knowledge. We are not obliged to cross check or verify information provided by you and we will not take any responsibility for any outcome or consequence as a result of you providing incorrect information or concealing any relevant information from us.</p>
<p>You understand that it is your responsibility to protect and own the information you provide on the Website including but not limited to your Username, Password, Email address, Contact Details and Mobile number. Teer Counter will not ask for your user account login password which is only to be entered at the time of login. At no other time should you provide your user account information to any user logged in on the Website or elsewhere. You undertake that you will not allow / login and then allow, any other person to use your user account using your username. You specifically understand and agree that we will not incur any liability for information provided by you to anyone which may result in your user account on the Website being exposed or misused by any other person.</p>
<p>You agree to use your Teer Counter user account solely for the purpose of participating in activities on the Website and for transactions which you may have to carry out in connection with availing the Services on the Website. Use or attempted use of your user account for any reason other than what is stated in the Terms may result in immediate termination of your user account.</p></br>
<p><strong>5. User Account validation and personal information verification</strong></p>
<p>Teer Counter may from time to time attempt to validate its users' user accounts. These attempts may be made via a phone call or via email. In the event that we are not able to get in touch with you the first time around, we will make additional attempts to establish contact with you. If the phone number and email provided by you is not correct, we bear no responsibility for the Services being interrupted due to our being unable to establish contact with you.</p>
<p>If we are unable to reach you or if the validation is unsuccessful, we reserve the right to disallow you from logging into the Website until we are able to satisfactorily validate your user account. We will in such events email you to notify you of the next steps regarding user account validation. We may also ask you for proof of identification and proof of address from time to time.</p>
<p>Upon receipt of suitable documents, we will try our best to enable your user account at the earliest. However, it may take a few business days to reinstate your user account.</p>
<p>In the event that we have made several attempts to reach out to you but have been unable to do so, we also reserve the right to permanently suspend your user account. The Privacy Policy of our Website forms a part of the Terms. All personal information which is of such nature that requires protection from unauthorized dissemination shall be dealt with in the manner provided in the&nbsp;<a title="Privacy Policy" href="../www.teerbhutan.com/privacypolicy.php.htm" target="_blank">Privacy Policy</a>&nbsp;of the Website.</p></br>
<p><strong>6. User restrictions</strong></p>
<p><strong>Anti-Cheating and Anti-Collusion:</strong></p>
<p>You undertake that you yourself will participate in all activities voluntarily, in which you have registered/joined and not use any form of external assistance for the same. You shall not add unauthorized components, create or use cheats, exploits, bots, hacks or any other third-party software designed to modify the Website or use any third-party software that intercepts, mines or otherwise collects information from or through the Website or through any Services. Any attempt to employ any such external assistance is strictly prohibited.</p>
<p>Money Laundering:&nbsp;You are prohibited from doing any activity on the Website that may be construed as money laundering, currently or in future.</p>
<p><strong>Anti-SPAMMING:</strong>&nbsp;Sending SPAM emails or any other form of unsolicited communication for obtaining registrations on the Website to benefit from any promotional program of Teer Counter or for any other purpose is strictly prohibited.</p>
<p><strong>Multiple IDs:</strong>&nbsp;Your registration on the Website is restricted to a single user account which will be used by you to avail of the Services provided on the Website. You are prohibited from creating or using multiple user IDs for registering on the Website.</p>
<p>You may not create a login name or password or upload, distribute, transmit, publish or post content through or on the Website or through any service or facility including any messaging facility provided by the Website which : is libelous, defamatory, obscene, intimidating, invasive of privacy, abusive, illegal, harassing; contains expressions of hatred, hurting religious sentiments, racial discrimination or pornography; is otherwise objectionable or undesirable (whether or not unlawful); would constitute incitement to commit a criminal offence; violates the rights of any person; is aimed at soliciting donations or other form of help; violates the intellectual property of any person; disparage in any manner Teer Counter or any of its subsidiaries, affiliates, licensors, associates, partners, sponsors, products, services, or websites; promotes a competing service or product; or violates any laws.</p>
<p>In the event we determine that the login name created by you is indecent, objectionable, offensive or otherwise undesirable, we shall notify you of the same and you shall promptly provide us with an alternate login name so that we can change your existing login name to the new name provided by you. If you fail to provide an alternate name, we reserve the right to either permanently suspend your user account or restore your user account only after a different acceptable login name has been provided by you.</p>
<p>You shall not host, intercept, emulate or redirect proprietary communication protocols, used by the Website, if any, regardless of the method used, including protocol emulation, reverse engineering or modification of the Website or any files that are part of the Website.</p>
<p>You shall not frame the Website. You may not impose editorial comments, commercial material or any information on the Website, alter or modify Content on the Website, or remove, obliterate or obstruct any proprietary notices or labels.</p>
<p>You shall not use Services on the Website for commercial purposes including but not limited to use in a cyber cafe as a computer gaming centre, network play over the Internet or through gaming networks or connection to an unauthorized server that copies the gaming experience on the Website.</p>
<p>You shall not upload, distribute or publish through the Website, any content which may contain viruses or computer contaminants (as defined in the Information Technology Act 2000 or such other laws in force in India at the relevant time) which may interrupt, destroy, limit the functionality or disrupt any software, hardware or other equipment belonging to us or that aids in providing the services offered by Teer Counter. You shall not disseminate or upload viruses, programs, or software whether it is harmful to the Website or not. Additionally, you shall not impersonate another person or user, attempt to get a password, other user account information, or other private information from a user, or harvest email addresses or other information.</p>
<p>You shall not purchase, sell, trade, rent, lease, license, grant a security interest in, or transfer your user account, Content, standings, rankings, ratings, or any other attributes appearing in, originating from or associated with the Website.</p>
<p><strong>Any form of fraudulent activity is strictly prohibited.</strong></p>
<p>Accessing or attempting to access the Services through someone else's user account is strictly prohibited.</p>
<p>If you are an officer, director, employee, consultant or agent of Teer Counter or a relative of such persons ("Associated Person"), you are not permitted to participate either directly or indirectly, in any Activity which entitles you to any prize on the Website, other than in the course of your engagement with Teer Counter. For these purposes, the term 'relative' shall include spouse and financially dependent parents and, children.</p>
<p>You shall not post any material or comment, on any media available for public access, which in our sole discretion, is defamatory or detrimental to our business interests, notwithstanding the fact that such media is not owned or controlled by us. In addition to any other action that we may take pursuant to the provision hereof, we reserve the right to remove any and all material or comments posted by you and restrict your access to any media available for public access that is either controlled or moderate by us; when in our sole opinion, any such material or comments posted by you is defamatory or detrimental to our business interests.</p></br>
<p><strong>7. Service Disruptions</strong></p>
<p>You may face Service disruptions, including, but not limited to disconnection or communication interferences due to issues in the internet infrastructure used for providing or accessing the Services or due to issues with the hardware and software used by you. You understand that Teer Counter has no control over these factors. Teer Counter shall not be responsible for any interruption in Services and you take full responsibility for any risk of loss due to Service interruptions for any such reason.</p>
<p>You understand, acknowledge and agree to the fact that if you are unable to participate in any Activity due to any error or omission attributable to Teer Counter, including technical or other glitches at our end, you will not hold Teer Counter responsible for the non participation in Activity and claim any damages from us.</p>
<p>You agree that under no circumstances shall you compel Teer Counter or hold Teer Counter liable to pay you any amount for any of the aforementioned errors/omissions of Teer Counter.</p>
<p><strong>8. Content</strong></p>
<p>All content and material on the Website including but not limited to information, images, marks, logos, designs, pictures, graphics, text content, hyperlinks, multimedia clips, animation, games and software (collectively referred to as "Content"), whether or not belonging to Teer Counter, are protected by applicable intellectual property laws. Additionally, all chat content, messages, images, recommendations, emails, images sent by any user can be logged/recorded by us and shall form part of Content and Teer Counter is free to use this material in any manner whatsoever.</p>
<p>The Website may contain information about or hyperlinks to third parties. In such a cases, we are not responsible in any manner and do not extend any express or implied warranty to the accuracy, integrity or quality of the content belonging to such third party websites. If you rely on any third party Content posted on the Website which does not belong to Teer Counter, you may do so solely at your own risk and liability.</p>
<p>If you visit any third party website through a third party Content posted on the website, you will be subject to terms and conditions applicable to it. We neither control nor are responsible for content on such third party websites. The fact of a link existing on our Website to a third party website is not an endorsement of that website by us.</p></br>
<p><strong>9. Promotions</strong></p>
<p>The details of various promotions organized on the Website can be found on the Website. Eligibility and applicable conditions for the ongoing promotional programs are provided on the website, which form a part of the Terms.</p>
<p>Activities offered under the promotions may be cancelled or discontinued by Teer Counter at any time without notice without any liability on Teer Counter whatsoever, except refund of entry fee, if applicable.</p></br>
<p><strong>10. License Agreement &amp; Intellectual Property</strong></p>
<p>All Content on the Website shall be utilized only for the purpose of availing Services and in conformity with the Terms.</p>
<p>You acknowledge that all ownership rights and all copyright and other intellectual property rights in the Content are owned by Teer Counter or our licensors and that you have no right title or other interest in any such items except as expressly stated in the Terms.</p>
<p>You are granted a personal, non-exclusive, non-assignable and non-transferable license to use the Content solely for the purposes of accessing and using the Services and for no other purpose whatsoever.</p>
<p>You shall not sublicense, assign or transfer the license granted to you, or rent or lease or part with the whole or any part of such license or of the Content included in such license.</p>
<p>You may not transfer, copy, reproduce, distribute, exploit, reverse engineer, disassemble, translate, decode, alter, make derivations from or make any other use of Content on the Websites in any manner other than as permitted for obtaining the Services provided on the website.</p>
<p>You may not hyperlink the Website to any other website without permission from us.</p>
<p>You may access information on, and download and print extracts from the Websites for your personal use only. No right, title or interest in any downloaded materials or software is transferred to you by downloading and you are expressly prohibited from using such materials for any commercial purpose unless agreed with us in writing.</p></br>
<p><strong>11. Voluntary termination</strong></p>
<p>You are free to discontinue use of the Services on the Website at any time by intimating us of your desire to do so by sending an email to us.</p></br>
<p><strong>12. User Account suspension</strong></p>
<p>We may suspend or otherwise put restrictions on your access to the Services on the Website during investigation for any of the following reasons: Suspected violation of Terms or other abuse of your user account; suspected breach of security of your user account; or if there have been charge-backs on your user account.</p>
<p>Our decision to suspend or restrict Service or any part thereof as we deem appropriate shall be final and binding on you.</p></br>
<p><strong>13. Breach and consequences</strong></p>
<p>In the event of breach of any of the Terms being evidenced from our investigation or if there is reasonable belief, in our sole discretion, that your continued access to the Website is detrimental to the interests of Teer Counter, our other users or the general public; we may in our sole discretion take any or all of the following actions: Permanently suspend your user account on the Website; Demand damages for breach and take appropriate civil action to recover such damages; and/or Initiate prosecution for violations that amount to offences in law. Additionally, in the event of committing material breach hereof, we reserve the right to bar you from future registration on the Website.</p>
<p>The decision of Teer Counter on the action to be taken as a consequence of breach shall be final and binding on you.</p>
<p>Any action taken by Teer Counter shall be without prejudice to our other rights and remedies available in law or equity.</p>
<p>&nbsp;</p></br>
<p><strong>14. Complaints &amp; disputes</strong></p>
<p>If you have a complaint, you should in the first instance contact the customer support team&nbsp;or write to us following the procedure given in the Contact Us section. Complaints should be made as soon as possible after circumstances arise that cause you to have a complaint.</p>
<p>You accept that any complaints and disputes are and remain confidential both whilst a resolution is sought and afterwards. You agree that you shall not disclose the existence, nature or any detail of any complaint or dispute to any third party.</p>
<p>Teer Counter shall make efforts to resolve complaints within reasonable time.</p>
<p>Our decision on complaints shall be final and binding on you.</p></br>
<p><strong>15. Modifications and alterations</strong></p>
<p>We may alter or modify the Terms at any time without giving prior notice to you. We may choose to notify of some changes in the Terms either by email or by displaying a message on the Website; however, our notification of any change shall not waive your obligation to keep yourself updated about the changes in the Terms. Your continued use of the Website and/or any Services offered constitutes your unconditional acceptance of the modified or amended Terms.</p>
<p>We may also post supplementary conditions for any Services that may be offered. In such an event, your use of those Services will be governed by the Terms as well as any such supplementary terms that those Services may be subject to.</p></br>
<p><strong>16. Limitation of liability</strong></p>
<p>In addition to specific references to limitation of liability of Teer Counter elsewhere in the Terms, under no circumstances (including, without limitation, in contract, negligence or other tort), Teer Counter shall be liable for any injury, loss, claim, loss of data, loss of income, loss of profit or loss of opportunity, loss of or damage to property, general damages or any direct, indirect, special, incidental, consequential, exemplary or punitive damages of any kind whatsoever arising out of or in connection with your access to, or use of, or inability to access or use, the Services on the Website. You further agree to indemnify us and our service providers and licensors against any claims in respect of any such matter.</p>
<p>Without limiting the generality of the foregoing, you specifically acknowledge, agree and accept that we are not liable to you for: the defamatory, undesirable or illegal conduct of any other user of the Services; any loss whatsoever arising from the use, abuse or misuse of your user account or any feature of our Services on the Websites; any loss incurred in transmitting information from or to us or from or to our Websites by the internet or by other connecting media; any technical failures, breakdowns, defects, delays, interruptions, improper or manipulated data transmission, data loss or corruption or communications' infrastructure failure, viruses or any other adverse technological occurrences arising in connection with your access to or use of our Services; the accuracy or completeness of any information services provided on the Website; any delay or failure on our part to intimate you where we may have concerns about your activities; and your activities / transactions on third party websites accessed through links or advertisements posted in the Website.</p>
<p>Not withstanding anything to the contrary contained in the Terms or elsewhere, you agree that our maximum aggregate liability for all your claims under this agreement, in all circumstances, shall be limited to Indian Rupees One Thousand only (INR. 1,000/)</p></br>
<p><strong>17. Disclaimer and indemnity</strong></p>
<p><strong>Disclaimer</strong></p>
<p>The Services on the Website and the Content present on it are provided strictly on "as is" basis with all faults or failings. Any representations, warranties, conditions or guarantee whatsoever, express or implied (including, without limitation, any implied warranty of accuracy, completeness, uninterrupted provision, quality, merchantability, fitness for a particular purpose or non-infringement) are specifically excluded to the fullest extent permitted by law. Teer Counter does not ensure or guarantee continuous, error-free, secure or virus-free operation of the website or its Content including software, Activities, your user account, the transactions in your user account or continued operation or availability of any facility on the website.</p>
<p>Additionally, Teer Counter does not promise or ensure that you will be able to access your user account or obtain Services whenever you want. It is entirely possible that you may not be able to access your user account or the Services provided by Teer Counter at times or for extended periods of time due to, but not limited to, system maintenance and updates.</p>
<p>Teer Counter disclaims responsibility and liability for any harm resulting from cancellation of any Activity organized by it. Teer Counter specifically disclaims any liability in connection with Activities or events made available or organized on the website which may require specific statutory permissions, in the event such permissions are denied or cancelled whether prior to or during such Activity or event.</p>
<p>Teer Counter specifically disclaims any liability in connection with your transactions with third parties which may have advertisements or are hyperlinked on the Website.</p>
<p>Teer Counter disclaims any liability in connection with violation of intellectual property rights of any party with respect to third party Content or user content posted on our Website. Intellectual property rights in any Content not belonging to us belong to the respective owners and any claims related to such content must be directly addressed to the respective owners.</p>
<p>Teer Counter specifically disclaims any liability arising out of the acts or omissions of the infrastructure providers or otherwise failure of internet services used for providing and accessing the Services.</p>
<p>Teer Counter disclaims liability for any risk or loss resulting to you from your participation in any Activity, including all risk of financial loss.</p>
<p><strong>Indemnity</strong></p>
<p>To the extent permitted by law, and in consideration for being allowed to participate in the Activity, you hereby agree to indemnify, save and hold harmless and defend us (to the extent of all benefits and awards, cost of litigation, disbursements and reasonable attorney's fees that we may incur in connection therewith including any direct, indirect or consequential losses, any loss of profit and loss of reputation) from any claims, actions, suits, taxes, damages, injuries, causes of action, penalties, interest, demands, expenses and/or awards asserted or brought against us by any person in connection with: infringement of their intellectual property rights by your publication of any content on our Website, defamatory, offensive or illegal conduct of any other player or for anything that turns out to be misleading, inaccurate, defamatory, threatening, obscene or otherwise illegal whether originating from another player or otherwise; use, abuse or misuse of your user account on our Website in any manner whatsoever; any disconnections, technical failures, system breakdowns, defects, delays, interruptions, manipulated or improper data transmission, loss or corruption of data or communication lines failure, distributed denial of service attacks, viruses or any other adverse technological occurrences arising in connection with your access to or use of our Website; and access of your user account by any other person accessing the Services using your username or password, whether or not with your authorization.</p></br>
<p>18. Governing law, dispute resolution &amp; jurisdiction</p>
<p>The Terms and Privacy Policy shall be interpreted in accordance with the laws of India.</p>
<p>Any dispute, controversy or claim arising out of the Terms or Privacy Policy shall be subject to the exclusive jurisdiction of the civil courts at Pune.</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<P STYLE="margin-bottom: 0in"><BR>
</P>
<P STYLE="margin-bottom: 0in"><BR>
</P>
   </div>



<div id="work1" class="container" style="background-color:white;">
					<!---works--->
					<div class="works">
							<div id="whatever">
									<div class="col-md-50 work-grid">
								    <div class="item1">
								        <a href="index.php"><img src="images/teer-result.jpg" title="Home" alt="Online Teer Result"/></a>									        
								    </div>  
							    </div> 
								<div class="col-md-50 work-grid">
								    <div class="item1">
								        <a href="Social/index.htm"><img src="images/teercounterSocial.jpg" title="teercounterSocial" alt="TeerCounter Social Network" /></a>						        
								    </div>  
							    </div> 
								<div class="col-md-50 work-grid">
								    <div class="item1">
								        <a href="dream-numbers.php"><img src="images/teer-dream-numbers.jpg" title="Dream Number" alt="Teer Dream Numbers" /></a>								        
								    </div>  
							    </div> 
								<div class="col-md-50 work-grid">
								    <div class="item1">
								        <a href="lotteries.html"><img src="images/Home.jpg" title="Teer and Lottery Home"  alt="TTeer and Lottery Home" /></a>								        
								    </div>  
							    </div> 
								<div class="col-md-50 work-grid">
								    <div class="item1">
								        <a href="contact-us.php"> <img  src="images/tc5.jpg" title="Contact Us" alt="Contact TeerCounter" /></a>
								    </div>  
							    </div> 
								<div class="col-md-50 work-grid">
								    <div class="item1">
								        <a href="previous-result.php"><img src="images/teer-previous-numbers.jpg" title="Previous Result" alt="Teer Previous Results"  /></a>								        
								    </div>  
							    </div> 	
						</div>
			</div>
			<!--anuja inserted footer-->
<div class='footer-left1'><a href='termsofuse.php'><u>Terms</u></a></div><div class='footer-center1'><a href='contact-us.php'><u>Contact Us</u></a></div><div class='footer-right1'><a href='privacypolicy.php'><u>Privacy Policy</u></a></div><!--footer ends here-->	</body>
</html>