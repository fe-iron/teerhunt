<!doctypehtml>
    <title>Teer | BHUTAN | Teer Results Online |</title>
    <meta content="text/html; charset=utf-8" http-equiv=Content-Type>
    <meta content="width=device-width,initial-scale=1,maximum-scale=1" name=viewport>
    <meta content="Check out previous results for BHUTAN teer at teerbhutan.com" name=description>
    <meta content="teer,BHUTAN,teer result,lottery result,previous results" name=keyword>
    <link href=css/style1.css rel=stylesheet media=all>
    <link href=images/16.ico rel="shortcut icon" type=image/x-icon>
    <div class=header id=home>
        <div class=top-header><a href=index.php><img alt=Teer src=images/teer.jpg title=Teer></a></div>
    </div>
    <div class=work id=work style=background-color:#fff>
        <div class=container style=background-color:#fff>
            <div class="head-one team-head text-center">
                <h2>Previous Results</h2>
                <p>
                <form action="/previous-result.php" method=POST><select id=selectmonth name=selectmonth>
                        <option value=0>Select Month
                        <option value=1>JANUARY
                        <option value=2>FEBUARY
                        <option value=3>MARCH
                        <option value=4>APRIL
                        <option value=5>MAY
                        <option value=6>JUNE
                        <option value=7>JULY
                        <option value=8>AUGUST
                        <option value=9>SEPTEMBER
                        <option value=10>OCTOBER
                        <option value=11>NOVEMBER
                        <option value=12>DECEMBER
                    </select> <select id=selectyear name=selectyear>
                        <option value=2021>2021</option>
                        <option value=2020>2020</option>
                    </select> <input name=submit style=margin-left:10px;padding:.5em;background-color:#3fd5ba
                        type=submit value=SUBMIT>
                    <p>
                </form>
                <table class=table></table><span></span>
                <table class=table>
                    <tr>
                        <th colspan=4>RESULTS : MARCH, 2021</th>
                    </tr>
                    <tr style='background-color:#3FD5BA; text-align:center'>
                        <td>CITY</td>
                        <td>DATE</td>
                        <td>F/R</td>
                        <td>S/R</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-03-01</td>
                        <td style='border:1px solid black;'>62</td>
                        <td style='border:1px solid black;'>62</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-03-02</td>
                        <td style='border:1px solid black;'>50</td>
                        <td style='border:1px solid black;'>42</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-03-03</td>
                        <td style='border:1px solid black;'>80</td>
                        <td style='border:1px solid black;'>39</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-03-04</td>
                        <td style='border:1px solid black;'>83</td>
                        <td style='border:1px solid black;'>14</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-03-05</td>
                        <td style='border:1px solid black;'>27</td>
                        <td style='border:1px solid black;'>51</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-03-06</td>
                        <td style='border:1px solid black;'>12</td>
                        <td style='border:1px solid black;'>30</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-03-07</td>
                        <td style='border:1px solid black;'>30</td>
                        <td style='border:1px solid black;'>68</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-03-08</td>
                        <td style='border:1px solid black;'>29</td>
                        <td style='border:1px solid black;'>40</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-03-09</td>
                        <td style='border:1px solid black;'>83</td>
                        <td style='border:1px solid black;'>98</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-03-10</td>
                        <td style='border:1px solid black;'>54</td>
                        <td style='border:1px solid black;'>26</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-03-11</td>
                        <td style='border:1px solid black;'>97</td>
                        <td style='border:1px solid black;'>75</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-03-12</td>
                        <td style='border:1px solid black;'>42</td>
                        <td style='border:1px solid black;'>86</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-03-13</td>
                        <td style='border:1px solid black;'>25</td>
                        <td style='border:1px solid black;'>34</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-03-14</td>
                        <td style='border:1px solid black;'>39</td>
                        <td style='border:1px solid black;'>74</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-03-15</td>
                        <td style='border:1px solid black;'>66</td>
                        <td style='border:1px solid black;'>00</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-03-16</td>
                        <td style='border:1px solid black;'>04</td>
                        <td style='border:1px solid black;'>98</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-03-17</td>
                        <td style='border:1px solid black;'>82</td>
                        <td style='border:1px solid black;'>46</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-03-18</td>
                        <td style='border:1px solid black;'>98</td>
                        <td style='border:1px solid black;'>12</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-03-19</td>
                        <td style='border:1px solid black;'>30</td>
                        <td style='border:1px solid black;'>54</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-03-20</td>
                        <td style='border:1px solid black;'>25</td>
                        <td style='border:1px solid black;'>02</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-03-21</td>
                        <td style='border:1px solid black;'>04</td>
                        <td style='border:1px solid black;'>91</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-03-22</td>
                        <td style='border:1px solid black;'>46</td>
                        <td style='border:1px solid black;'>52</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-03-23</td>
                        <td style='border:1px solid black;'>19</td>
                        <td style='border:1px solid black;'>85</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-03-24</td>
                        <td style='border:1px solid black;'>77</td>
                        <td style='border:1px solid black;'>31</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-03-25</td>
                        <td style='border:1px solid black;'>83</td>
                        <td style='border:1px solid black;'>46</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-03-26</td>
                        <td style='border:1px solid black;'>61</td>
                        <td style='border:1px solid black;'>79</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-03-27</td>
                        <td style='border:1px solid black;'>98</td>
                        <td style='border:1px solid black;'>32</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-03-28</td>
                        <td style='border:1px solid black;'>85</td>
                        <td style='border:1px solid black;'>25</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-03-29</td>
                        <td style='border:1px solid black;'>75</td>
                        <td style='border:1px solid black;'>68</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-03-30</td>
                        <td style='border:1px solid black;'>46</td>
                        <td style='border:1px solid black;'>94</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-03-31</td>
                        <td style='border:1px solid black;'>68</td>
                        <td style='border:1px solid black;'>15</td>
                    </tr>
                </table><span></span>
                <table class=table>
                    <tr>
                        <th colspan=4>RESULTS : APRIL, 2021</th>
                    </tr>
                    <tr style='background-color:#3FD5BA; text-align:center'>
                        <td>CITY</td>
                        <td>DATE</td>
                        <td>F/R</td>
                        <td>S/R</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-04-01</td>
                        <td style='border:1px solid black;'>10</td>
                        <td style='border:1px solid black;'>31</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-04-02</td>
                        <td style='border:1px solid black;'>98</td>
                        <td style='border:1px solid black;'>95</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-04-03</td>
                        <td style='border:1px solid black;'>05</td>
                        <td style='border:1px solid black;'>77</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-04-04</td>
                        <td style='border:1px solid black;'>35</td>
                        <td style='border:1px solid black;'>89</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-04-05</td>
                        <td style='border:1px solid black;'>73</td>
                        <td style='border:1px solid black;'>46</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-04-06</td>
                        <td style='border:1px solid black;'>81</td>
                        <td style='border:1px solid black;'>30</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-04-07</td>
                        <td style='border:1px solid black;'>49</td>
                        <td style='border:1px solid black;'>02</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-04-08</td>
                        <td style='border:1px solid black;'>63</td>
                        <td style='border:1px solid black;'>58</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-04-09</td>
                        <td style='border:1px solid black;'>28</td>
                        <td style='border:1px solid black;'>96</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-04-10</td>
                        <td style='border:1px solid black;'>51</td>
                        <td style='border:1px solid black;'>18</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-04-11</td>
                        <td style='border:1px solid black;'>49</td>
                        <td style='border:1px solid black;'>57</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-04-12</td>
                        <td style='border:1px solid black;'>97</td>
                        <td style='border:1px solid black;'>82</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-04-13</td>
                        <td style='border:1px solid black;'>60</td>
                        <td style='border:1px solid black;'>47</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-04-14</td>
                        <td style='border:1px solid black;'>15</td>
                        <td style='border:1px solid black;'>06</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-04-15</td>
                        <td style='border:1px solid black;'>72</td>
                        <td style='border:1px solid black;'>53</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-04-16</td>
                        <td style='border:1px solid black;'>61</td>
                        <td style='border:1px solid black;'>18</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-04-17</td>
                        <td style='border:1px solid black;'>35</td>
                        <td style='border:1px solid black;'>42</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-04-18</td>
                        <td style='border:1px solid black;'>34</td>
                        <td style='border:1px solid black;'>94</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-04-19</td>
                        <td style='border:1px solid black;'>80</td>
                        <td style='border:1px solid black;'>22</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-04-20</td>
                        <td style='border:1px solid black;'>95</td>
                        <td style='border:1px solid black;'>74</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-04-21</td>
                        <td style='border:1px solid black;'>48</td>
                        <td style='border:1px solid black;'>03</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-04-22</td>
                        <td style='border:1px solid black;'>56</td>
                        <td style='border:1px solid black;'>89</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-04-23</td>
                        <td style='border:1px solid black;'>99</td>
                        <td style='border:1px solid black;'>68</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-04-24</td>
                        <td style='border:1px solid black;'>05</td>
                        <td style='border:1px solid black;'>82</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-04-25</td>
                        <td style='border:1px solid black;'>66</td>
                        <td style='border:1px solid black;'>62</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-04-26</td>
                        <td style='border:1px solid black;'>23</td>
                        <td style='border:1px solid black;'>81</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-04-27</td>
                        <td style='border:1px solid black;'>49</td>
                        <td style='border:1px solid black;'>01</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-04-28</td>
                        <td style='border:1px solid black;'>62</td>
                        <td style='border:1px solid black;'>93</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-04-29</td>
                        <td style='border:1px solid black;'>85</td>
                        <td style='border:1px solid black;'>06</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-04-30</td>
                        <td style='border:1px solid black;'>31</td>
                        <td style='border:1px solid black;'>28</td>
                    </tr>
                </table><span></span>
                <table class=table>
                    <tr>
                        <th colspan=4>RESULTS : MAY, 2021</th>
                    </tr>
                    <tr style='background-color:#3FD5BA; text-align:center'>
                        <td>CITY</td>
                        <td>DATE</td>
                        <td>F/R</td>
                        <td>S/R</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-05-01</td>
                        <td style='border:1px solid black;'>82</td>
                        <td style='border:1px solid black;'>80</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-05-02</td>
                        <td style='border:1px solid black;'>99</td>
                        <td style='border:1px solid black;'>13</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-05-03</td>
                        <td style='border:1px solid black;'>96</td>
                        <td style='border:1px solid black;'>53</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-05-04</td>
                        <td style='border:1px solid black;'>53</td>
                        <td style='border:1px solid black;'>97</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-05-05</td>
                        <td style='border:1px solid black;'>67</td>
                        <td style='border:1px solid black;'>91</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-05-06</td>
                        <td style='border:1px solid black;'>53</td>
                        <td style='border:1px solid black;'>33</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-05-07</td>
                        <td style='border:1px solid black;'>11</td>
                        <td style='border:1px solid black;'>05</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-05-08</td>
                        <td style='border:1px solid black;'>89</td>
                        <td style='border:1px solid black;'>43</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-05-09</td>
                        <td style='border:1px solid black;'>59</td>
                        <td style='border:1px solid black;'>45</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-05-10</td>
                        <td style='border:1px solid black;'>87</td>
                        <td style='border:1px solid black;'>88</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-05-11</td>
                        <td style='border:1px solid black;'>02</td>
                        <td style='border:1px solid black;'>43</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-05-12</td>
                        <td style='border:1px solid black;'>87</td>
                        <td style='border:1px solid black;'>90</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-05-13</td>
                        <td style='border:1px solid black;'>11</td>
                        <td style='border:1px solid black;'>37</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-05-14</td>
                        <td style='border:1px solid black;'>29</td>
                        <td style='border:1px solid black;'>49</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-05-15</td>
                        <td style='border:1px solid black;'>19</td>
                        <td style='border:1px solid black;'>90</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-05-16</td>
                        <td style='border:1px solid black;'>34</td>
                        <td style='border:1px solid black;'>70</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-05-17</td>
                        <td style='border:1px solid black;'>84</td>
                        <td style='border:1px solid black;'>03</td>
                    </tr>
                    <tr style='text-align: center;'>
                        <td style='border:1px solid black;'>BHUTAN</td>
                        <td style='border:1px solid black;'>2021-05-18</td>
                        <td style='border:1px solid black;'>21</td>
                        <td style='border:1px solid black;'>26</td>
                    </tr>
                </table><span></span>
            </div>
            <div class=container id=work1 style=background-color:#fff>
                <div class=works>
                    <div id=whatever>
                        <div class="col-md-50 work-grid">
                            <div class=item1><a href=index.php><img alt="Online Teer Result" src=images/teer-result.jpg
                                        title=Home></a></div>
                        </div>
                        <div class="col-md-50 work-grid">
                            <div class=item1><a href=#><img alt="TeerCounter Social Network"
                                        src=images/teercounterSocial.jpg title=teercounterSocial></a></div>
                        </div>
                        <div class="col-md-50 work-grid">
                            <div class=item1><a href=dream-numbers.php><img alt="Teer Dream Numbers"
                                        src=images/teer-dream-numbers.jpg title="Dream Number"></a></div>
                        </div>
                        <div class="col-md-50 work-grid">
                            <div class=item1><a href=win-prizes.php.htm><img alt="TeerCounter Win Prizes"
                                        src=images/teer-win-prizes.jpg title="Win Prizes"></a></div>
                        </div>
                        <div class="col-md-50 work-grid">
                            <div class=item1><a href=lotteries.html><img alt="TeerCounter Forum"
                                        src=images/teer-forum.jpg title=Groups></a></div>
                        </div>
                        <div class="col-md-50 work-grid">
                            <div class=item1><a href=common-numbers.php><img alt=" Teer Common Numbers"
                                        src=images/teer-common-numbers.jpg title="Common Number"></a></div>
                        </div>
                    </div>
                </div>
                <div class=footer-left1><a href=termsofuse.php><u>Terms</u></a></div>
                <div class=footer-center1><a href=contact-us.php><u>Contact Us</u></a></div>
                <div class=footer-right1><a href=privacypolicy.php><u>Privacy Policy</u></a></div>
                </body>

                </html>